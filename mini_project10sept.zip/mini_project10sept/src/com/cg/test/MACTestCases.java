package com.cg.test;

import org.junit.jupiter.api.Test;

import com.cg.dao.ApplicationDAO;
import com.cg.dao.ApplicationDAOImpl;
import com.cg.service.MACService;
import com.cg.service.MACServiceImpl;

import junit.framework.Assert;

public class MACTestCases {

	MACService mac=new MACServiceImpl();
	ApplicationDAO app=new ApplicationDAOImpl();
	@Test
	public void TestCase1()
	{
		Assert.assertNotNull(mac.getAllScheduledPrograms());
	}
	@Test
	public void TestCase2()
	{
		mac.updateStatus("ACCEPTED",1001);
	}
	@Test
	public void TestCase3()
	{
		mac.updateStatus("ACCEPTED",1001);
		Assert.assertEquals("ACCEPTED", app.applicationStatus(1001));
	}
	@Test
	public void TestCase4()
	{
		Assert.assertNotNull(mac.getAllApplications());
	}
	@Test
	public void TestCase5()
	{
		Assert.assertNotNull(mac.showApplicationByStatus("ACCEPTED"));
	}
	@Test
	public void TestCase6()
	{
		Assert.assertEquals("ACCEPTED		",mac.ReturnStatus(1001));
	}
}
