 package com.cg.dao;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.dto.Application;
import com.cg.dto.ProgramOffered;
import com.cg.dto.ProgramScheduled;

public interface AdminDAO {

	boolean checkLogin(String loginId, String password);
	void addProgram(ProgramOffered obj);
	void deleteProgram(String programName);
	void scheduleProgram(ProgramScheduled obj);
	ArrayList<ProgramScheduled> getScheduledProgram(Date startDate, Date endDate);
	ArrayList<Application> getStatus(String status);
	ArrayList<String> getProgramsOffered();

}
